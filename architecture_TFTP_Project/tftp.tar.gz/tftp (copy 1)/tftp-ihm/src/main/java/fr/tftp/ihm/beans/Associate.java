package fr.tftp.ihm.beans;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class Associate {

	private String civility;
	private String lastName;
	private String firstName;
	
    @DateTimeFormat(pattern = "dd-MM-yyyy")
	private String birthDate;
    
	private String street;
	private String postCode;
	private String city;
	
	private String INA;
	private int nbreParts;
	
	public int getNbreParts() {
		return nbreParts;
	}
	public void setNbreParts(int nbreParts) {
		this.nbreParts = nbreParts;
	}
	public String getINA() {
		return INA;
	}
	public void setINA(String INA) {
		this.INA = INA;
	}
	public String getCivility() {
		return civility;
	}
	public void setCivility(String civility) {
		this.civility = civility;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}

}
