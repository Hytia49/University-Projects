package fr.tftp.ihm.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import fr.tftp.ihm.beans.Associate;
import fr.tftp.ihm.service.AssocieService;

@Controller
public class CreerAssocieController {

	@Autowired
	private AssocieService dao;

	@RequestMapping(
			  value = "/save", 
			  method = RequestMethod.POST)
    public String creerAssocie(@ModelAttribute("associe") Associate associe) {
		dao.creer(associe);
		
        return "redirect:/list";
    }	
	
	@RequestMapping(
			  value = "/register", 
			  method = RequestMethod.GET)
	public String afficherFormulaireInscription(Model model) {
		
		model.addAttribute("associe", new Associate());
		
		return "inscription";
		
	}		
}
