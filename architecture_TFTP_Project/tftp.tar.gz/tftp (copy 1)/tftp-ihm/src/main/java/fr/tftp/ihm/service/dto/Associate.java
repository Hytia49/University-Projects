package fr.tftp.ihm.service.dto;

import java.util.Date;

/**
 * Objet de type tftp-service pour appeler le service
 * @author Lambert et Jadeau
 *
 */
public class Associate {
	
	private String firstName;
	private String lastName;
	private Date birthDate;
	
	private Address address;
	
	private String INA;
	private int nbreParts;
	
	public int getNbreParts() {
		return nbreParts;
	}
	public void setNbreParts(int nbreParts) {
		this.nbreParts = nbreParts;
	}
	public String getINA() {
		return INA;
	}
	public void setINA(String INA) {
		this.INA = INA;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

}
