package fr.tftp.ihm.service;

import java.util.List;

import fr.tftp.ihm.beans.Associate;


/**
 * Interface d'accès aux données des associés
 * @author Lambert et Jadeau
 *
 */
public interface AssocieService {
	
	/**
	 * Liste les associés enregistrés
	 * @return
	 */
	public List<Associate> lister();

	/**
	 * Permet de créer un associé
	 * @param associate
	 * @return
	 */
	public Associate creer(Associate associate);
	
}
