package fr.tftp.ihm.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import fr.tftp.ihm.beans.Associate;
import fr.tftp.ihm.service.dto.Address;



@Service // Déclare la classe comme une classe de service 
public class AssocieServiceImpl implements AssocieService {

	@Autowired
	private RestTemplate restTemplate;
	
	@Override
	public List<Associate> lister() {

		// Construction de l'URL pour l'appel su WS
		String url = "http://localhost:8081/associates";

		// Appel du WS Rest
		ObjectMapper mapper = new ObjectMapper();
		
		// Conversion des objets DTO issu du service ima-service en objet Bean dans l'IHM
		// Cette conversion est causée par la librairie Jackson qui n'a pas suffisamment d'information
		// pour transformer le JSON en java : donc par défaut il utilise un LinkedHashMap
		// Erreur en test : java.lang.ClassCastException: java.util.LinkedHashMap cannot be cast to
		// https://stackoverflow.com/questions/28821715/java-lang-classcastexception-java-util-linkedhashmap-cannot-be-cast-to-com-test
		List<fr.tftp.ihm.service.dto.Associate> associates = mapper.convertValue(restTemplate.getForObject(url, 
				List.class, 
				url), new TypeReference<List<fr.tftp.ihm.service.dto.Associate>>(){});
		
		List<Associate> ret = new ArrayList<Associate>();
		for (Iterator<fr.tftp.ihm.service.dto.Associate> iterator = associates.iterator(); iterator.hasNext();) {
			fr.tftp.ihm.service.dto.Associate associate = (fr.tftp.ihm.service.dto.Associate) iterator.next();
			ret.add(convertAssociateDTOtoBean(associate));
		}
		
		return ret;
	}

	@Override
	public Associate creer(Associate associate) {
		// Construction de l'URL pour l'appel su WS
		String url = "http://localhost:8081/associate/create";

		Associate ret = null;
		try {
			fr.tftp.ihm.service.dto.Associate AssociateDTO = convertAssociateBeanToDTO(associate);

			// Appel du WS Rest
			ResponseEntity<Associate> response = restTemplate.postForEntity(url, AssociateDTO, Associate.class);
			ret = response.getBody();
			
		} catch (ParseException e) {
			// Gérer un message d'erreur
		}
		
		return ret;
	}
	
	/**
	 * Convertit un objet Model IHM en objet DTO pour appeler le service tftp-service
	 * @param bean
	 * @return
	 * @throws ParseException
	 */
	private fr.tftp.ihm.service.dto.Associate convertAssociateBeanToDTO(Associate bean) throws ParseException {
		fr.tftp.ihm.service.dto.Associate dto = new fr.tftp.ihm.service.dto.Associate();
		
		dto.setFirstName(bean.getFirstName());
		dto.setLastName(bean.getLastName());
		
		DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		dto.setBirthDate(df.parse(bean.getBirthDate()));
		dto.setINA(bean.getINA());
		dto.setNbreParts(bean.getNbreParts());
		
		if (StringUtils.hasText(bean.getCity()) && StringUtils.hasText(bean.getPostCode())) {
			Address address = new Address();
			address.setStreet(bean.getStreet());
			address.setPostCode(bean.getPostCode());
			address.setCity(bean.getCity());
			dto.setAddress(address);
		}
		
		return dto;
	}
	
	/**
	 * Convertit un objet DTO issu du service tftp-service en objet Model IHM 
	 * @param dto
	 * @return
	 */
	private Associate convertAssociateDTOtoBean(fr.tftp.ihm.service.dto.Associate dto) {
		Associate ret = new Associate();
		
		ret.setFirstName(dto.getFirstName());
		ret.setLastName(dto.getLastName());
		ret.setINA(dto.getINA());
		ret.setNbreParts(dto.getNbreParts());
		
		DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		ret.setBirthDate(df.format(dto.getBirthDate()));

	
		if (dto.getAddress() != null) {
			ret.setStreet(dto.getAddress().getStreet());
			ret.setPostCode(dto.getAddress().getPostCode());
			ret.setCity(dto.getAddress().getCity());
		}
		
		return ret;
	}
}
