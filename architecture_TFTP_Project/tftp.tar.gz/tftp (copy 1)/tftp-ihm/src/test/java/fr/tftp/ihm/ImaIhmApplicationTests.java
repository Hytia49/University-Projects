package fr.tftp.ihm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImaIhmApplicationTests {

	@Test
	void contextLoads() {
	}

}
