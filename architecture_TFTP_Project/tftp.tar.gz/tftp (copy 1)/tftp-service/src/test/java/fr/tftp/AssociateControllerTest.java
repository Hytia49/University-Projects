package fr.tftp;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.logging.Logger;

import org.assertj.core.util.DateUtil;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.databind.ObjectMapper;

import fr.tftp.App;
import fr.tftp.controller.entities.dto.Address;
import fr.tftp.controller.entities.dto.Associate;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = App.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class AssociateControllerTest {
    @LocalServerPort
	protected int port;

    @Autowired
    private TestRestTemplate testRestTemplate;
    
    private static String idIde;
    
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    
	private static Logger logger = Logger.getLogger(AssociateControllerTest.class.getName());
    
    @Test
    @Order(4)    
    public void testGetAssociates() throws Exception {
    	ResponseEntity<List> response = testRestTemplate.getForEntity("http://localhost:"+port+"/Associates", List.class);
    	assertTrue(response.getStatusCode().equals(HttpStatus.OK));
    	assertTrue(response.getBody().size() == 1);
    }

    @Test
    @Order(3)    
    public void testGetAssociateNotExistDetail() throws Exception {

    	ResponseEntity<Associate> response = testRestTemplate.getForEntity("http://localhost:"+port+"/Associate/11111", Associate.class);
    	assertTrue(response.getStatusCode().equals(HttpStatus.NOT_FOUND));
    }
    
    @Test
    @Order(2)
    public void testGetAssociateDetail() throws Exception {

    	ResponseEntity<Associate> response = testRestTemplate.getForEntity("http://localhost:"+port+"/Associate/"+idIde, Associate.class);
    	assertTrue(response.getStatusCode().equals(HttpStatus.OK));
    }    
    
    @Test
    @Order(1)
    public void testCreateAssociate() throws Exception {
    	
    	Associate dummy = new Associate();
    	dummy.setLastName("DUPONT");
    	dummy.setFirstName("Pierre");
    	dummy.setBirthDate(DateUtil.parse("1995-01-28"));
    	
    	Address address = new Address();
    	address.setStreet("44 rue Rabelais");
    	address.setPostCode("49000");
    	address.setCity("ANGERS");
    	dummy.setAddress(address);

    	logger.info("Object to insert : "+OBJECT_MAPPER.writeValueAsString(dummy));
    	
    	ResponseEntity<Associate> response = testRestTemplate.postForEntity("http://localhost:"+port+"/Associate/create", dummy, Associate.class);
    	assertTrue(response.getBody() != null);
    	
    	idIde = response.getBody().getINA();
    	
    	assertTrue(response.getStatusCode().equals(HttpStatus.CREATED));
     }    
    
    @Test
    public void testDeleteAssociate() throws Exception {
    }        
    
    @Test
    public void testUpdateAssociate() throws Exception {
    }            
}