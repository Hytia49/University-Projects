package fr.tftp.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import fr.tftp.controller.entities.dao.Adresse;
import fr.tftp.controller.entities.dao.Associe;
import fr.tftp.controller.entities.dao.services.AssociateRepositoryInterface;
import fr.tftp.controller.entities.dto.Address;
import fr.tftp.controller.entities.dto.Associate;

@RestController
public class AssociateController {
	
	@Autowired
	private AssociateRepositoryInterface associateRepository;

	
	@GetMapping("/associates")
	public HttpEntity<List<Associate>> getAssociates() {
		
		Iterable<Associe> e = associateRepository.findAll();
		
		List<Associate> list = new ArrayList<Associate>();
		for (Iterator<Associe> iterator = e.iterator(); iterator.hasNext();) {
			list.add(createDTOFromassocieDAO(iterator.next()));
		}
		
		return ResponseEntity.ok(list);
	}
	
	@GetMapping("/associate/{id}")
	public HttpEntity<Associate> getAssociateDetail(@PathVariable String id) {
		
		Optional<Associe> e = associateRepository.findById(new Long(id));

		// La doc sur les Optional : https://www.javatpoint.com/java-8-optional
		if (!e.isPresent()) {
			return new ResponseEntity<Associate>(HttpStatus.NOT_FOUND);
		}
	
		return new ResponseEntity<Associate>(createDTOFromassocieDAO(e.get()), HttpStatus.OK);
	}	
	
	@PostMapping("/associate/create")
	public HttpEntity<Associate> createAssociate(@RequestBody Associate Associate) {  // Créer un objet Associate ici pour passer les valeurs

		if (!StringUtils.hasText(Associate.getLastName()) || !StringUtils.hasText(Associate.getFirstName())) {
			return new ResponseEntity<Associate>(HttpStatus.BAD_REQUEST);
		}
		
		Associe associeDAO = createDAOFromAssociateDTO(Associate);
		
		associateRepository.save(associeDAO);
		
		return new ResponseEntity<Associate>(createDTOFromassocieDAO(associeDAO), HttpStatus.CREATED);
	}		
	
	@DeleteMapping("/associate/delete/{id}")
	public HttpEntity deleteAssociate(@PathVariable String id) {
		return null;
	}
	
	@PutMapping("/associate/update")
	public HttpEntity<Associate> updateAssociate(@RequestBody Associate Associate) {
		return null;
	}	

	/**
	 * Convertit un objet Associate DTO en associe DAO
	 * @param Associate
	 * @return
	 */
	private Associe createDAOFromAssociateDTO(Associate associate) {
		Associe associe = new Associe();
		associe.setPrenom(associate.getFirstName());
		associe.setNom(associate.getLastName());
		associe.setDateNaissance(associate.getBirthDate());

		// Créé une nouvelle instance d'adresse sans se soucier
		// de savoir si une même adresse existe déjà
		if (associate.getAddress() != null) {
			Adresse adresseDAO = new Adresse();
			adresseDAO.setRue(associate.getAddress().getStreet());
			adresseDAO.setCodePostal(associate.getAddress().getPostCode());
			adresseDAO.setVille(associate.getAddress().getCity());
			associe.setAdresse(adresseDAO);
		}
		
		return associe;
	}
	
	/**
	 * Convertit un objet associe DAO en Associate DTO
	 * @param Associate
	 * @return
	 */
	private Associate createDTOFromassocieDAO(Associe associe) {
		
		Associate associate = new Associate();
		
		associate.setFirstName(associe.getPrenom());
		associate.setLastName(associe.getNom());
		associate.setBirthDate(associe.getDateNaissance());
		associate.setINA(Long.toString(associe.getId().longValue()));

		Address address = new Address();
		address.setStreet(associe.getAdresse().getRue());
		address.setPostCode(associe.getAdresse().getCodePostal());
		address.setCity(associe.getAdresse().getVille());
		associate.setAddress(address);
		
		return associate;
	}	
}
