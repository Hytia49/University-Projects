package fr.tftp.controller.entities.dao.services;

import org.springframework.data.repository.CrudRepository;

import fr.tftp.controller.entities.dao.Associe;

public interface AssociateRepositoryInterface extends CrudRepository<Associe, Long> {


}
