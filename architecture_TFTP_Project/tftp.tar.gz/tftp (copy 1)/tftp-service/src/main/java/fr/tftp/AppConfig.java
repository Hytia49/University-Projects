package fr.tftp;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
}